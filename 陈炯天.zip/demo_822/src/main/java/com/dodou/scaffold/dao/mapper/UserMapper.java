package com.dodou.scaffold.dao.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dodou.scaffold.dao.model.UserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;


@Mapper
public interface UserMapper extends BaseMapper<UserInfo> {
    //通过用户的账号密码查询是否有该用户
    Integer selectUser(@Param("userName") String userName, @Param("password") String password);

    //通过用户的名字查询是否有相同的名字
    Integer selectUserName(@Param("userName") String userName);

    //通过注册码查询用户的信息
    UserInfo selectAll(String zhuce);

    //通过userid查询该id下的会员
    List<UserInfo> recursion(Long id);

    //通过姓名查询子会员
    UserInfo getAllNodes(String userName);

    //通过userid去查询parentid为userid的子会员
    UserInfo selectNodes(Integer userId);

    //根据起止时间查询信息
    IPage<UserInfo> getAllByTime(@Param("page")Page<UserInfo> page,@Param("param") HashMap<String, Object> map);
}
