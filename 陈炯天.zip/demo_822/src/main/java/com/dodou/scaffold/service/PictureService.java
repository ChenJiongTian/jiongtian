package com.dodou.scaffold.service;

import org.springframework.stereotype.Service;

/**
 * @InterfaceName PictureService
 * @Description TODO
 * @Author checkZH
 * @Date 2019/8/3010:00
 * @Version 1.0
 */
@Service
public interface PictureService {
}
