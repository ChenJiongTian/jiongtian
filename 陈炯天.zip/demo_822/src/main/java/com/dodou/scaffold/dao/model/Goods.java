package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Past;

/**
 * Created by Mybatis Generator 2019/09/11
 */
@ApiModel(value = "com.dodou.scaffold.dao.model.Goods")
@Data
@TableName(value = "goods")
public class Goods implements Serializable {
    /**
     * 商品编号
     */
    @TableId(value = "goods_id", type = IdType.AUTO)
    @ApiModelProperty(value = "商品编号")
    private Long goodsId;

    /**
     * 商品标题
     */
    @NotBlank(message = "商品标题不能为空")
    @TableField(value = "goods_title")
    @ApiModelProperty(value = "商品标题")
    private String goodsTitle;

    /**
     * 商品标签
     */
    @NotBlank(message = "商品标签不能为空")
    @TableField(value = "goods_label")
    @ApiModelProperty(value = "商品标签")
    private String goodsLabel;

    /**
     * 商品图片
     */
    @TableField(value = "goods_img")
    @ApiModelProperty(value = "商品图片")
    private String goodsImg;

    /**
     * 商品内容
     */
    @NotBlank(message = "商品内容不能为空")
    @TableField(value = "goods_content")
    @ApiModelProperty(value = "商品内容")
    private String goodsContent;

    /**
     * 商品内容
     */
    @NotBlank(message = "商品类型不能为空")
    @TableField(value = "goods_type")
    @ApiModelProperty(value = "商品类型")
    private String goodsType;

    /**
     * 商品时间
     */
    @NotBlank(message = "商品添加时间不能为空")
    @TableField(value = "goods_time")
    @ApiModelProperty(value = "商品时间")
    private Date goodsTime;

    @TableField(exist = false)
    private Date times;

    @TableField(exist = false)
    private List<Setmeal> setmealinfo;


    private static final long serialVersionUID = 1L;

    public static final String COL_GOODS_TITLE = "goods_title";

    public static final String COL_GOODS_LABEL = "goods_label";

    public static final String COL_GOODS_IMG = "goods_img";

    public static final String COL_GOODS_CONTENT = "goods_content";

    public static final String COL_GOODS_TYPE = "goods_type";

    public static final String COL_GOODS_TIME = "goods_time";
}