package com.dodou.scaffold.controller;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dodou.scaffold.comon.CommonFileUtil;
import com.dodou.scaffold.dao.model.PictureInfo;
import com.dodou.scaffold.dao.model.ProductInfo;
import com.dodou.scaffold.service.impl.PictureServiceImpl;
import com.dodou.scaffold.service.impl.ProductServiceImpl;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * @ClassName ProductController
 * @Author Cjt
 * @Date 2019/8/309:50
 * @Version 1.0
 */
@RestController
public class ProductController {
    private final static Logger logger = LoggerFactory.getLogger(FileController.class);
    @Autowired
    ProductServiceImpl productService;
    @Autowired
    private CommonFileUtil fileUtil;
    @Autowired
    PictureServiceImpl pictureService;
    @ApiOperation(value = "新增商品图片", notes = "新增商品并添加相应的图片")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "files", value = "文件名", required = true, dataType = "MultipartFile"),
            @ApiImplicitParam(name = "productName", value = "商品名称", required = true, dataType = "String"),
            })
    @RequestMapping(value = "/addProduct", method = RequestMethod.POST)
    public String addProduct(@RequestParam("fileName") MultipartFile[] files, String productName) throws IOException {
        //新增一条商品信息
        ProductInfo p = new ProductInfo();
        //将商品名称插入
        p.setProductName(productName);
        //判断如果插入成功
        if (productService.save(p)) {
            //对多个文件进行循环插入
            for (MultipartFile file : files) {
                //实例化一个图片bean
                PictureInfo o = new PictureInfo();
                //验证文件是不是为空
                if (file.isEmpty()) {
                    logger.info("文件不存在");
                }
                //在图片表中插入商品id
                o.setProductId(p.getProductId());
                //在图片表中插入图片地址
                o.setPictureUrl(fileUtil.uploadFile(file));
                //插入数据库
                pictureService.save(o);
            }
            return "添加成功";
        } else {
            return "添加失败";
        }
    }
    @ApiOperation(value = "查询商品信息", notes = "根据商品名称查询商品信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "productName", value = "商品名", required = true, dataType = "String"),
             })
    @RequestMapping(value = "selectProductByName", method = RequestMethod.GET)
    public List<ProductInfo> selectAllProduct(String productName) {
        //查询
        List<ProductInfo> aa = productService.selectProductByName(productName);
        //返回
        return aa;
    }
    @ApiOperation(value = "删除商品信息", notes = "根据商品名称删除商品信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "productName", value = "商品名", required = true, dataType = "String"),
    })
    @RequestMapping(value = "deleteProductByName", method = RequestMethod.DELETE)
    public String deleteProductByName(String productName) {
        //首先根据商品名称查出商品的实体
        ProductInfo aa = productService.getOne(new QueryWrapper<ProductInfo>().eq("product_name", productName));
        //首先删除从表
        if (pictureService.remove(new QueryWrapper<PictureInfo>().eq("product_id", aa.getProductId()))) {
            //再删除主表
            if (productService.remove(new QueryWrapper<ProductInfo>().eq("product_id", aa.getProductId()))) {
                return "删除成功";
            } else {
                return "删除失败";
            }

        } else {
            return "删除失败";
        }
    }
    @ApiOperation(value = "修改商品信息", notes = "修改商品信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "productName", value = "商品名", required = true, dataType = "String"),
            @ApiImplicitParam(name = "productId", value = "商品id", required = true, dataType = "Integer"),
    })
    @RequestMapping(value = "updateProduct", method = RequestMethod.PUT)
    public String updateByProductName(String productName, Integer productId) {
        //添加一个实体
        ProductInfo aa = new ProductInfo();
        aa.setProductName(productName);
        aa.setProductId(productId);
        //调用修改接口
        if (productService.updateById(aa)) {
            return "修改成功";
        } else {
            return "修改失败";
        }
    }
    @ApiOperation(value = "查询所有信息", notes = "通过sql语句查询")
    @RequestMapping(value = "selectProducts", method = RequestMethod.GET)
    public List<ProductInfo> selectProducts(){
        return productService.selectProducts();
    }
    @ApiOperation(value = "查询所有信息", notes = "通过xml collection查询")
    @RequestMapping(value = "selectAllProducts", method = RequestMethod.GET)
    public List<ProductInfo> selectAllProducts(){
        return productService.selectAllProducts();
    }
}
