package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

/**
 * Created by Mybatis Generator 2019/09/15
 */
@ApiModel(value = "com.dodou.scaffold.dao.model.Stu")
@Data
@TableName(value = "stu")
public class Stu implements Serializable {
    /**
     * 学生id
     */
    @TableId(value = "stu_id", type = IdType.AUTO)
    @ApiModelProperty(value = "学生id")
    private Integer stuId;

    /**
     * 学生姓名
     */
    @TableField(value = "stu_name")
    @ApiModelProperty(value = "学生姓名")
    private String stuName;


    @TableField(exist = false)
    private List<Fraction> fractions;

    private static final long serialVersionUID = 1L;

    public static final String COL_STU_NAME = "stu_name";
}