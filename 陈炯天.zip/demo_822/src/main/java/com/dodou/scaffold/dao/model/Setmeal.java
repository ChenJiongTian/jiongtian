package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Min;

/**
* Created by Mybatis Generator 2019/09/11
*/
@ApiModel(value="com.dodou.scaffold.dao.model.Setmeal")
@Data
@TableName(value = "setmeal")
public class Setmeal implements Serializable {
    /**
     * 套餐编号
     */
    @TableId(value = "setmeal_id", type = IdType.AUTO)
    @ApiModelProperty(value="套餐编号")
    private Long setmealId;

    /**
     * 套餐名称
     */
    @NotBlank(message = "商品标签不能为空")
    @TableField(value = "setmeal_name")
    @ApiModelProperty(value="套餐名称")
    private String setmealName;

    /**
     * 套餐数量
     */
    @Min(0)
    @TableField(value = "setmeal_number")
    @ApiModelProperty(value="套餐数量")
    private Integer setmealNumber;

    /**
     * 套餐价格
     */
    @Min(0)
    @TableField(value = "setmeal_price")
    @ApiModelProperty(value="套餐价格")
    private BigDecimal setmealPrice;

    /**
     * 套餐运费
     */
    @Min(0)
    @TableField(value = "setmeal_freight")
    @ApiModelProperty(value="套餐运费")
    private BigDecimal setmealFreight;

    /**
     * 套餐库存
     */
    @Min(0)
    @TableField(value = "setmeal_stock")
    @ApiModelProperty(value="套餐库存")
    private Integer setmealStock;

    /**
     * 套餐添加时间
     */
    @NotBlank(message = "套餐添加时间不能为空")
    @TableField(value = "setmeal_time")
    @ApiModelProperty(value="套餐添加时间")
    private Date setmealTime;

    /**
     * 商品编号
     */
    @NotBlank(message = "商品编号不能为空")
    @TableField(value = "goods_id")
    @ApiModelProperty(value="商品编号")
    private Long goodsId;

    @TableField(exist = false)
    private Setmeal[] setmeals;

}