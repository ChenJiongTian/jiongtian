package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.dao.mapper.StuMapper;
import com.dodou.scaffold.dao.model.Stu;
import com.dodou.scaffold.service.StuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName StuServiceImpl
 * @Author Cjt
 * @Date 2019/9/1515:10
 * @Version 1.0
 */
@Service
public class StuServiceImpl extends ServiceImpl<StuMapper, Stu> implements StuService {
    @Autowired
    StuMapper stuMapper;
    @Override
    public List<Stu> selectAll() {
        return stuMapper.selectAll();
    }

    @Override
    public boolean insertByList(List<Stu> stuList) {
        return stuMapper.insertByList(stuList);
    }
}
