package com.dodou.scaffold.controller.ro;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName GoodsRO
 * @Author Cjt
 * @Date 2019/9/199:13
 * @Version 1.0
 */
@Data
public class GoodsRO {
    private String goodsTitle;
    private String goodsLable;
    private String goodsContent;
    private String goodsType;
    private String[] setmealName;
    private Integer[] setmealNumber;
    private BigDecimal[] setmealPrice;
    private BigDecimal[] setmealFreight;
    private Integer[] setmealStock;
    private Long goodsId;
    private Long[] setmealId;
}
