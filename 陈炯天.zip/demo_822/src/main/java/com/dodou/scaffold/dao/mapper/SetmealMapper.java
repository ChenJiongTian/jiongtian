package com.dodou.scaffold.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dodou.scaffold.dao.model.Setmeal;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
* Created by Mybatis Generator 2019/09/11
*/
@Mapper
public interface SetmealMapper extends BaseMapper<Setmeal> {
}