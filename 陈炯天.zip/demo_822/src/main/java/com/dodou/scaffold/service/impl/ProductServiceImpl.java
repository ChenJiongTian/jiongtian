package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.dao.mapper.ProductMapper;
import com.dodou.scaffold.dao.model.ProductInfo;
import com.dodou.scaffold.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName ProductServiceImpl
 * @Author Cjt
 * @Date 2019/8/309:52
 * @Version 1.0
 */
@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, ProductInfo> implements ProductService {
    /**
     *
     */
    @Autowired
    private ProductMapper productMapper;
    @Override
    //通过名称查询商品信息
    public List<ProductInfo> selectProductByName(String productName) {
        return productMapper.selectProductByName(productName);
    }

    @Override
    public List<ProductInfo> selectProducts() {
        return productMapper.selectProducts();
    }

    @Override
    public List<ProductInfo> selectAllProducts() {
        return productMapper.selectAllProducts();
    }
}
