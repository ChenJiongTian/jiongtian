package com.dodou.scaffold.service;

import com.dodou.scaffold.dao.model.ProductInfo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @InterfaceName ProductService
 * @Description TODO
 * @Author checkZH
 * @Date 2019/8/309:52
 * @Version 1.0
 */
@Service
public interface ProductService {
    //通过名字查询商品的信息
    List<ProductInfo> selectProductByName(String  productName);
    //通过语句查询查询所有商品及图片信息
    List<ProductInfo> selectProducts();
    //通过查询方式
    List<ProductInfo> selectAllProducts();
}
