package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName PictureInfo
 * @Author Cjt
 * @Date 2019/8/309:26
 * @Version 1.0
 */
@Data
@TableName("picture_info")
public class PictureInfo {
    //图片的id
    @TableId(type = IdType.AUTO)
    private Integer pictureId;
    //图片地址
    private String pictureUrl;
    //商品id
    private Integer productId;

}
