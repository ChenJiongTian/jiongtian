package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@TableName("user_info")
public class UserInfo {
    //查询代数
    @TableField(exist = false)
    private Integer mun;
    @TableId(type = IdType.AUTO)
    //user_id
    //@TableField("userId")
    private Integer userId;
    //user_name
    private String userName;
    //password
    private String password;
    //zhuce
    private String recommendationCode;
    //parentId
    //@TableField("parent_id")
    private Integer parentId;
    //存储子会员
    @TableField(exist = false)
    private List<UserInfo> nodes = new ArrayList<>();
    //注册时间
    private String registrationTime;

}
