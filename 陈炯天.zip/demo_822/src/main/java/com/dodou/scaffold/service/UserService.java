package com.dodou.scaffold.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dodou.scaffold.dao.model.UserInfo;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public interface UserService extends IService<UserInfo> {
    //    注册
    int insert(UserInfo user);

    //    查询
    List<UserInfo> selectByMap(Map user);

    //   登录
    Integer selectUser(String userName, String password);

    //判断用户名是否重名
    Integer selectUserName(String userName);

    //通过注册码查询用户信息
    UserInfo selectAll(String zhuce);

    //通过userid查询该id下的会员
    List<UserInfo> recursion(Long userId);

    //通过姓名查询子会员
    UserInfo getAllNodes(String userName);

    //通过起止时间进行筛选
    //List<UserInfo> getAllByTime(UserInfo aa);
    IPage<UserInfo> listQueryUser(Page<UserInfo> page, String userName, Integer recommendationCode, String startTime, String endingTime);



    IPage<UserInfo> selectAllByTime(Page<UserInfo> page , HashMap<String, Object> map);
    }
