package com.dodou.scaffold.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dodou.scaffold.dao.model.Setmeal;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @InterfaceName SetmealService
 * @Description TODO
 * @Author checkZH
 * @Date 2019/9/1114:11
 * @Version 1.0
 */
@Service
public interface SetmealService extends IService<Setmeal> {
}
