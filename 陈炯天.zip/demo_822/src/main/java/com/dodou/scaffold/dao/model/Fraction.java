package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
* Created by Mybatis Generator 2019/09/15
*/
@ApiModel(value="com.dodou.scaffold.dao.model.Fraction")
@Data
@TableName(value = "fraction")
public class Fraction implements Serializable {
    /**
     * 成绩id
     */
     @TableId(value = "fraction_id", type = IdType.AUTO)
    @ApiModelProperty(value="成绩id")
    private Integer fractionId;

    /**
     * 成绩
     */
    @TableField(value = "fraction_num")
    @ApiModelProperty(value="成绩")
    private Integer fractionNum;

    /**
     * 学生id
     */
    @TableField(value = "stu_id")
    @ApiModelProperty(value="学生id")
    private Integer stuId;

    private static final long serialVersionUID = 1L;

    public static final String COL_FRACTION_NUM = "fraction_num";

    public static final String COL_STU_ID = "stu_id";
}