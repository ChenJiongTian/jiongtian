package com.dodou.scaffold.dao.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.List;

/**
 * @ClassName ProductInfo
 * @Author Cjt
 * @Date 2019/8/309:25
 * @Version 1.0
 */
@Data
@TableName("product_info")
public class ProductInfo {
    //商品id
    @TableId(type = IdType.AUTO)
    private Integer productId;
    //商品名称
    private String productName;
    //图片的实体类
    @TableField(exist = false)
    private List<PictureInfo> listPicture;
}
