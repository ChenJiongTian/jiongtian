package com.dodou.scaffold.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dodou.scaffold.dao.model.Fraction;
import org.apache.ibatis.annotations.Mapper;

/**
* Created by Mybatis Generator 2019/09/15
*/
@Mapper
public interface FractionMapper extends BaseMapper<Fraction> {
}