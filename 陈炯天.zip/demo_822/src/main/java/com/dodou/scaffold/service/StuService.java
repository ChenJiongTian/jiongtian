package com.dodou.scaffold.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dodou.scaffold.dao.model.Stu;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @InterfaceName StuService
 * @Description TODO
 * @Author checkZH
 * @Date 2019/9/1515:09
 * @Version 1.0
 */
public interface StuService extends IService<Stu> {
    List<Stu> selectAll();
    boolean insertByList(@Param("stuList") List<Stu> stuList);
}
