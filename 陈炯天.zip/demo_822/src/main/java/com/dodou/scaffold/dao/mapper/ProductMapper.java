package com.dodou.scaffold.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dodou.scaffold.dao.model.PictureInfo;
import com.dodou.scaffold.dao.model.ProductInfo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @InterfaceName ProductMapper
 * @Description TODO
 * @Author checkZH
 * @Date 2019/8/3010:03
 * @Version 1.0
 */
@Mapper
public interface ProductMapper extends BaseMapper<ProductInfo> {
//通过商品名称查询该商品的所有信息
List<ProductInfo> selectProductByName(String productName);
//通过商品id查询该商品的所有图片地址
PictureInfo selectPictureByProductId(Integer productId);
//通过sql语句查询所有
List<ProductInfo> selectProducts();
//通过xml collection查询所有
List<ProductInfo> selectAllProducts();
}
