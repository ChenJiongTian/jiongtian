package com.dodou.scaffold.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dodou.scaffold.dao.mapper.UserMapper;
import com.dodou.scaffold.dao.model.UserInfo;
import com.dodou.scaffold.handler.LoginHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@Component("loginHandler")
public class LoginHandlerImpl implements LoginHandler {
    @Autowired
    private UserMapper userMapper;
    @Override
    public UserDetails loadUserByUsername(String username) {
        UserInfo users = userMapper.selectOne(new QueryWrapper<UserInfo>().eq("user_name", username));
        String password = "";
        if(Objects.nonNull(users)){
            password = users.getPassword();
        }

        return new org.springframework.security.core.userdetails.User(username,password,true,
                true,true,true,
                AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER"));

    }
}
