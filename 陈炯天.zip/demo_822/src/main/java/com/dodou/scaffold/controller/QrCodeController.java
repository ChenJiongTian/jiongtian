package com.dodou.scaffold.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dodou.scaffold.dao.model.UserInfo;
import com.dodou.scaffold.properties.AppProperties;
import com.dodou.scaffold.service.impl.UserServiceImpl;
import com.dodou.scaffold.support.base.ResponseData;
import com.dodou.scaffold.utils.GoogleUtils;
import com.dodou.scaffold.utils.QRCodeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import sun.misc.BASE64Encoder;

/**
 * @ClassName QrCodeController
 * @Author Cjt
 * @Date 2019/8/2914:03
 * @Version 1.0
 */
@RestController
public class QrCodeController {
    @Autowired
    UserServiceImpl userService;
    @Autowired
    GoogleUtils googleUtils;
    @Autowired
    AppProperties appProperties;


    //String QRCodeUtils.encodes(内容, logo地址, logo是否压缩);
    @PostMapping("/google")
    public ResponseData getGoogle(String userName) {
        String recommendationCode = userService.getOne(new QueryWrapper<UserInfo>().eq("user_name", userName)).getRecommendationCode();
        //转码
        String encodes = QRCodeUtils.encodes(recommendationCode, null, false);
        System.out.println(encodes);
        return ResponseData.success(new ResponseData<>(appProperties.getStateSuccess(),"成功",encodes));

    }
}
