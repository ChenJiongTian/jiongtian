package com.dodou.scaffold.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dodou.scaffold.dao.model.PictureInfo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @InterfaceName PictureMapper
 * @Description TODO
 * @Author checkZH
 * @Date 2019/8/3010:03
 * @Version 1.0
 */
@Mapper
public interface PictureMapper extends BaseMapper<PictureInfo> {
}
