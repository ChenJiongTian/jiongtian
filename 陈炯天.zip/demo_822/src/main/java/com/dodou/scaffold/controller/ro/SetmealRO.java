package com.dodou.scaffold.controller.ro;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName SetmealRO
 * @Author Cjt
 * @Date 2019/9/1914:07
 * @Version 1.0
 */
@Data
public class SetmealRO {
    private String setmealName;
    private Integer setmealNumber;
    private BigDecimal setmealPrice;
    private BigDecimal setmealFreight;
    private Integer setmealStock;
    private Long goodsId;

}
