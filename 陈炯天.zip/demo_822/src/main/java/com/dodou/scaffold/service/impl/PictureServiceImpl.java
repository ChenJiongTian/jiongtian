package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.dao.mapper.PictureMapper;
import com.dodou.scaffold.dao.model.PictureInfo;
import com.dodou.scaffold.service.PictureService;
import org.springframework.stereotype.Service;

/**
 * @ClassName PictureServiceImpl
 * @Author Cjt
 * @Date 2019/8/3010:00
 * @Version 1.0
 */
@Service
public class PictureServiceImpl extends ServiceImpl<PictureMapper, PictureInfo> implements PictureService {
}
