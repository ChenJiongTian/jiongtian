package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.dao.mapper.FractionMapper;
import com.dodou.scaffold.dao.model.Fraction;
import com.dodou.scaffold.service.FractionService;
import org.springframework.stereotype.Service;

/**
 * @ClassName FractionServiceImpl
 * @Author Cjt
 * @Date 2019/9/1515:13
 * @Version 1.0
 */
@Service
public class FractionServiceImpl extends ServiceImpl<FractionMapper, Fraction> implements FractionService {
}
