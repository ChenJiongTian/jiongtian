package com.dodou.scaffold.controller;

import com.dodou.scaffold.controller.ro.GoodsRO;
import com.dodou.scaffold.controller.ro.SetmealRO;
import com.dodou.scaffold.dao.model.Goods;
import com.dodou.scaffold.dao.model.Setmeal;
import com.dodou.scaffold.service.GoodsService;
import com.dodou.scaffold.service.SetmealService;
import com.dodou.scaffold.support.base.ResponseData;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @ClassName GoodsController
 * @Author Cjt
 * @Date 2019/9/1114:14
 * @Version 1.0
 */
@RestController
@Slf4j
@RequestMapping("/Goods")
@Api(description = "商品curd", tags = "对商品的操作")
public class GoodsAndSetmealController {
    @Autowired
    GoodsService goodsService;
    @Autowired
    SetmealService setmealService;


    @ApiOperation(value = "新增商品", notes = "新增商品并且添加对应的套餐信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "goodsTitle", value = "商品标题", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsLable", value = "商品标签", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsContent", value = "商品内容", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsType", value = "商品类型", required = true, dataType = "String"),
            @ApiImplicitParam(name = "setmealName", value = "套餐名称", required = true, dataType = "String"),
            @ApiImplicitParam(name = "setmealNumber", value = "套餐数量", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "setmealPrice", value = "套餐价格", required = true, dataType = "BigDecimal"),
            @ApiImplicitParam(name = "setmealFreight", value = "套餐运费", required = true, dataType = "BigDecimal"),
            @ApiImplicitParam(name = "setmealStock", value = "套餐库存", required = true, dataType = "Integer")
    })
    @PostMapping(value = "/insertGoods")
    public ResponseData insertGoods(GoodsRO goodsRO) {
        return goodsService.saveGoodsAndSetmeal(goodsRO);
    }

    @ApiOperation(value = "删除商品", notes = "删除商品以及对应的所有套餐信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "goodsId", value = "商品ID", required = true, dataType = "Long"),
    })
    @DeleteMapping(value = "/deleteGoods")
    public ResponseData deleteGoods(Long goodsId) {
        return goodsService.deleteGoodsAndSetmeal(goodsId);
    }

    @ApiOperation(value = "修改商品", notes = "修改商品")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "goodsTitle", value = "商品标题", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsLable", value = "商品标签", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsContent", value = "商品内容", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsType", value = "商品类型", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsId", value = "商品id", required = true, dataType = "Long"),
            @ApiImplicitParam(name = "setmealName", value = "套餐名称", required = true, dataType = "String"),
            @ApiImplicitParam(name = "setmealNumber", value = "套餐数量", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "setmealPrice", value = "套餐价格", required = true, dataType = "BigDecimal"),
            @ApiImplicitParam(name = "setmealFreight", value = "套餐运费", required = true, dataType = "BigDecimal"),
            @ApiImplicitParam(name = "setmealStock", value = "套餐库存", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "setmealId", value = "套餐ID", required = true, dataType = "Long")
    })
    @PutMapping(value = "/updateGoods")
    public ResponseData updateGoods(GoodsRO goodsRO) {
        return goodsService.updateGoodsAndSetmeal(goodsRO);
    }

    @ApiOperation(value = "查询商品", notes = "查询商品(条件)")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "goodsId", value = "商品ID", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "goodsLable", value = "商品标签", required = true, dataType = "String"),
            @ApiImplicitParam(name = "goodsType", value = "商品类型", required = true, dataType = "String")
    })
    @GetMapping(value = "/selectGoodsByInfo")
    public ResponseData selectGoodsByInfo(Long goodsId, String goodsType, Date time) {
        Goods goods = new Goods();
        goods.setGoodsId(goodsId);
        goods.setGoodsTitle(goodsType);
        goods.setTimes(time);
        return goodsService.selectGoodsByInfo(goods);
    }

    @ApiOperation(value = "添加单个套餐", notes = "根据goodsId添加单个套餐")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "setmealName", value = "套餐名称", required = true, dataType = "String"),
            @ApiImplicitParam(name = "setmealNumber", value = "套餐数量", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "setmealPrice", value = "套餐价格", required = true, dataType = "Long"),
            @ApiImplicitParam(name = "setmealFreight", value = "套餐运费", required = true, dataType = "Long"),
            @ApiImplicitParam(name = "setmealStock", value = "套餐库存", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "goodsId", value = "商品编号", required = true, dataType = "Integer"),
    })
    @PostMapping(value = "/insertSetmeal")
    public ResponseData insertSetmeal(SetmealRO setmealRO) {
        Setmeal setmeal = new Setmeal();
        setmeal.setSetmealName(setmealRO.getSetmealName());
        setmeal.setSetmealNumber(setmealRO.getSetmealNumber());
        setmeal.setSetmealPrice(setmealRO.getSetmealPrice());
        setmeal.setSetmealFreight(setmealRO.getSetmealFreight());
        setmeal.setSetmealStock(setmealRO.getSetmealStock());
        setmeal.setGoodsId(setmealRO.getGoodsId());
        setmeal.setSetmealTime(new Date());
        if (setmealService.save(setmeal)) {
            return new ResponseData<>(200, "添加新套餐成功", null);
        } else {
            return new ResponseData<>(500, "添加新套餐失败", null);
        }
    }


    @ApiOperation(value = "修改套餐", notes = "修改单个套餐")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "setmealName", value = "套餐名称", required = true, dataType = "String"),
            @ApiImplicitParam(name = "setmealNumber", value = "套餐数量", required = true, dataType = "Integer"),
            @ApiImplicitParam(name = "setmealPrice", value = "套餐价格", required = true, dataType = "Long"),
            @ApiImplicitParam(name = "setmealFreight", value = "套餐运费", required = true, dataType = "Long"),
            @ApiImplicitParam(name = "setmealStock", value = "套餐库存", required = true, dataType = "Integer")
    })
    @RequestMapping(value = "updateSetmeal", method = RequestMethod.POST)
    public ResponseData updateSetmeal(Setmeal setmeal) {
        Setmeal setmeal1 = new Setmeal();
        setmeal1.setSetmealName(setmeal.getSetmealName());
        setmeal1.setSetmealNumber(setmeal.getSetmealNumber());
        setmeal1.setSetmealPrice(setmeal.getSetmealPrice());
        setmeal1.setSetmealFreight(setmeal.getSetmealFreight());
        setmeal1.setSetmealStock(setmeal.getSetmealStock());
        setmeal1.setSetmealTime(new Date());
        setmeal1.setSetmealId(setmeal.getSetmealId());
        if (setmealService.save(setmeal1)) {
            return new ResponseData<>(200, "修改套餐成功", null);
        } else {
            return new ResponseData<>(500, "修改套餐失败", null);
        }
    }
}
