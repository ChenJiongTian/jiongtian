package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.controller.ro.GoodsRO;
import com.dodou.scaffold.dao.mapper.GoodsMapper;
import com.dodou.scaffold.dao.mapper.SetmealMapper;
import com.dodou.scaffold.dao.model.Goods;
import com.dodou.scaffold.dao.model.Setmeal;
import com.dodou.scaffold.service.GoodsService;
import com.dodou.scaffold.service.SetmealService;
import com.dodou.scaffold.support.base.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @ClassName GoodsServiceImpl
 * @Author Cjt
 * @Date 2019/9/1114:12
 * @Version 1.0
 */
@Service
public class GoodsServiceImpl extends ServiceImpl<GoodsMapper, Goods> implements GoodsService {
    @Autowired
    SetmealService setmealService;


    //条件查询商品及所有套餐
    @Override
    public ResponseData selectGoodsByInfo(Goods goods) {
        return new ResponseData<>(200, "查询成功", baseMapper.selectGoodsByInfo(goods));
    }


    //添加商品以及套餐
    @Override
    public ResponseData saveGoodsAndSetmeal(GoodsRO goodsRO) {
        //实例化一个商品类
        Goods goods = new Goods();
        goods.setGoodsTitle(goodsRO.getGoodsTitle());
        goods.setGoodsLabel(goodsRO.getGoodsLable());
        goods.setGoodsContent(goodsRO.getGoodsContent());
        goods.setGoodsType(goodsRO.getGoodsType());
        goods.setGoodsTime(new Date());
        //添加商品信息进数据库，如果添加成功，则开始添加该商品的套餐信息
        if (save(goods)) {
            for (int i = 0; i < goodsRO.getSetmealName().length; i++) {
                //实例化一个套餐类
                Setmeal setmeal = new Setmeal();
                setmeal.setSetmealName(goodsRO.getSetmealName()[i]);
                setmeal.setSetmealNumber(goodsRO.getSetmealNumber()[i]);
                setmeal.setSetmealPrice(goodsRO.getSetmealPrice()[i]);
                setmeal.setSetmealFreight(goodsRO.getSetmealFreight()[i]);
                setmeal.setSetmealStock(goodsRO.getSetmealStock()[i]);
                setmeal.setSetmealTime(new Date());
                setmeal.setGoodsId(goods.getGoodsId());
                //添加套餐信息进数据库
                setmealService.save(setmeal);
            }
            return new ResponseData<>(200, "添加成功", null);
        } else {
            return new ResponseData<>(500, "添加失败", null);
        }
    }


    //删除商品及套餐
    @Override
    public ResponseData deleteGoodsAndSetmeal(Long goodsId) {
        //根据商品id删除商品
        if (removeById(goodsId)) {
            //再删除该商品对应的套餐信息
            if (setmealService.remove(new QueryWrapper<Setmeal>().eq("goods_id", goodsId))) {
                return new ResponseData<>(200, "删除成功", null);
            } else {
                return new ResponseData<>(500, "删除失败", null);
            }
        } else {
            return new ResponseData<>(500, "删除失败", null);
        }
    }


    //修改商品及套餐
    @Override
    public ResponseData updateGoodsAndSetmeal(GoodsRO goodsRO) {
        //实例化一个商品类
        Goods goods = new Goods();
        goods.setGoodsId(goodsRO.getGoodsId());
        goods.setGoodsTitle(goodsRO.getGoodsTitle());
        goods.setGoodsLabel(goodsRO.getGoodsLable());
        goods.setGoodsContent(goodsRO.getGoodsContent());
        goods.setGoodsType(goodsRO.getGoodsType());
        goods.setGoodsTime(new Date());
        //进行修改
        if (updateById(goods)) {
            //修改商品成功后继续循环修改套餐信息
            for (int i = 0; i < goodsRO.getSetmealName().length; i++) {
                //实例化套餐类
                Setmeal setmeal = new Setmeal();
                setmeal.setSetmealName(goodsRO.getSetmealName()[i]);
                setmeal.setSetmealNumber(goodsRO.getSetmealNumber()[i]);
                setmeal.setSetmealPrice(goodsRO.getSetmealPrice()[i]);
                setmeal.setSetmealFreight(goodsRO.getSetmealFreight()[i]);
                setmeal.setSetmealStock(goodsRO.getSetmealStock()[i]);
                setmeal.setSetmealTime(new Date());
                setmeal.setGoodsId(goods.getGoodsId());
                setmeal.setSetmealId(goodsRO.getSetmealId()[i]);
                //修改套餐信息
                setmealService.updateById(setmeal);
            }
            return new ResponseData<>(200, "修改成功", null);
        } else {
            return new ResponseData<>(500, "修改失败", null);
        }
    }

}
