package com.dodou.scaffold.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dodou.scaffold.dao.model.UserInfo;
import com.dodou.scaffold.service.impl.UserServiceImpl;
import com.dodou.scaffold.support.base.ResponseData;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

@RestController
public class UserController {
    //引入service层
    @Autowired
    private UserServiceImpl userService;
    //引入密码加密工具
    @Autowired
    private PasswordEncoder passwordEncoder;

    @ApiOperation(value = "注册", notes = "通过注册码注册用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userName", value = "用户姓名", required = true, dataType = "String"),
            @ApiImplicitParam(name = "password", value = "用户密码", required = true, dataType = "String"),
            @ApiImplicitParam(name = "recommendationCode", value = "推荐码", required = true, dataType = "String")
    })
    @RequestMapping(value = "saveUser", method = RequestMethod.POST)
    public String saveUser(String userName, String password, String recommendationCode) {
        //获取当前时间
        Date date = new Date();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
        String hh = sf.format(date);
        //通过注册码查询用户的信息
        UserInfo oo = userService.selectAll(recommendationCode);
        if (userService.selectUserName(userName) == 0) {
            //实例化一个实体类
            UserInfo info = new UserInfo();
            //将数据插入
            info.setUserName(userName);
            //插入加密后的密码
            info.setPassword(passwordEncoder.encode(password));
            //随机生成一个字符串当做注册码插入
            String verifyCode = String.valueOf(new Random().nextInt(899999) + 100000);
            info.setRecommendationCode(verifyCode);
            //插入查询出来的用户id
            info.setParentId(oo.getUserId());
            //插入注册时间
            info.setRegistrationTime(hh);
            //查看是否插入成功
            Integer index = userService.insert(info);
            if (index > 0) {
                return "注册用户成功！";
            } else {
                return "注册用户失败！";
            }
        } else {
            return "已存在该用户，请勿重复注册";
        }

    }

    @ApiOperation(value = "用语句递归查询", notes = "递归查询")
    @ApiImplicitParam(name = "userId", value = "用户ID", required = true, dataType = "String")
    @RequestMapping(value = "recursion", method = RequestMethod.GET)
    public String recursion(Long userId) {
        List<UserInfo> aa = userService.recursion(userId);
        if (aa.size() > 0) {
            JSONArray json = JSONArray.fromObject(aa);
            String result = json.toString();
            return result;
        } else {
            return "该节点下无会员";
        }
    }


    @ApiOperation(value = "递归查询", notes = "递归查询")
    @ApiImplicitParam(name = "userName", value = "用户姓名", required = true, dataType = "String")
    @RequestMapping(value = "getNodes", method = RequestMethod.GET)
    public UserInfo recursion1(String userName) {
        UserInfo aa = userService.getAllNodes(userName);
        return aa;
    }

    @ApiOperation(value = "查询中加入节点数", notes = "查询中加入节点数")
    @RequestMapping(value = "getNodes1", method = RequestMethod.GET)
    public List<UserInfo> getNodes1(String userName) {
        UserInfo user1 = userService.getAllNodes(userName);
        list1 = new ArrayList<>();
        return digui(user1.getNodes(), 0);
    }

    private List<UserInfo> list1;

    public List<UserInfo> digui(List<UserInfo> list, Integer mun) {
        if (CollectionUtils.isNotEmpty(list)) {
            mun++;
            for (UserInfo user : list) {
                user.setMun(mun);
                list1.add(user);
                if (CollectionUtils.isNotEmpty(user.getNodes())) {
                    digui(user.getNodes(), mun);
                }
            }
        }
        return list1;
    }

    @ApiOperation(value = "条件查询", notes = "通过给的条件查全部")
    @RequestMapping(value = "selectAllByCondition", method = RequestMethod.GET)
    public ResponseData selectAllByCondition(String userName, Integer recommendationCode, String startTime, String endingTime, Long current, Long size) {
        Page<UserInfo> page = new Page<>(current, size);
        IPage<UserInfo> iPage = userService.listQueryUser(page, userName, recommendationCode, startTime, endingTime);
        return ResponseData.success(iPage);
    }

    @ApiOperation(value = "条件查询", notes = "通过给的条件在xml文件中查全部")
    @RequestMapping(value = "selectAllByTime", method = RequestMethod.GET)
    public ResponseData selectAllByTime(String userName, Integer recommendationCode, String startTime, String endTime, Long current, Long size) {
        Page<UserInfo> page = new Page<>(current, size);
        HashMap<String, Object> map=new HashMap<>();
        map.put("userName",userName);
        map.put("recommendationCode",recommendationCode);
        map.put("startTime",startTime);
        map.put("endTime",endTime);
        IPage<UserInfo> iPage=userService.selectAllByTime(page,map);
        return  ResponseData.success(iPage);
    }


}




