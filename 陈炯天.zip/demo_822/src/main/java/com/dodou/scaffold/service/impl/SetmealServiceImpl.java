package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.dao.mapper.SetmealMapper;
import com.dodou.scaffold.dao.model.Setmeal;
import com.dodou.scaffold.service.SetmealService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName SetmealServiceImpl
 * @Author Cjt
 * @Date 2019/9/1114:12
 * @Version 1.0
 */
@Service
public class SetmealServiceImpl extends ServiceImpl<SetmealMapper, Setmeal> implements SetmealService {
}
