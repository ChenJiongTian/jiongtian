package com.dodou.scaffold.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dodou.scaffold.controller.ro.GoodsRO;
import com.dodou.scaffold.dao.model.Goods;
import com.dodou.scaffold.support.base.ResponseData;

/**
 * @InterfaceName GoodsService
 * @Description TODO
 * @Author checkZH
 * @Date 2019/9/1114:11
 * @Version 1.0
 */
public interface GoodsService extends IService<Goods> {
    //条件查询商品及套餐
    ResponseData selectGoodsByInfo(Goods goods);

    //添加商品及批量添加套餐
    ResponseData saveGoodsAndSetmeal(GoodsRO goodsRO);

    //删除商品并且批量删除所有套餐
    ResponseData deleteGoodsAndSetmeal(Long goodsId);

    //修改商品并且批量修改套餐
    ResponseData updateGoodsAndSetmeal(GoodsRO goodsRO);
}
