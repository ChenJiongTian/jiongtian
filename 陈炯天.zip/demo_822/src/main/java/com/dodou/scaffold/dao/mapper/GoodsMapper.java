package com.dodou.scaffold.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dodou.scaffold.dao.model.Goods;
import com.dodou.scaffold.dao.model.Setmeal;
import com.dodou.scaffold.support.base.ResponseData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by Mybatis Generator 2019/09/11
 */
@Mapper
public interface GoodsMapper extends BaseMapper<Goods> {
    //通过商品的条件查询符合条件的商品及套餐
    List<Goods> selectGoodsByInfo(@Param("goods") Goods goods);

    //通过条件查出goodsId给套餐表查询该商品的套餐
    Goods selectSetmeal(@Param("goods") Goods goods);
}