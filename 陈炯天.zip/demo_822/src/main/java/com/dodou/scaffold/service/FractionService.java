package com.dodou.scaffold.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dodou.scaffold.dao.model.Fraction;

/**
 * @InterfaceName FractionService
 * @Description TODO
 * @Author checkZH
 * @Date 2019/9/1515:13
 * @Version 1.0
 */
public interface FractionService extends IService<Fraction> {
}
