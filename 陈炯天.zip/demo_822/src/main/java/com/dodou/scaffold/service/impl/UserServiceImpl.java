package com.dodou.scaffold.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dodou.scaffold.dao.mapper.UserMapper;
import com.dodou.scaffold.dao.model.UserInfo;
import com.dodou.scaffold.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, UserInfo> implements UserService {
    @Autowired
    private UserMapper userMapper;

    //注册方法
    @Override
    public int insert(UserInfo user) {
        return userMapper.insert(user);
    }

    //查询方法
    @Override
    public List<UserInfo> selectByMap(Map user) {
        return userMapper.selectByMap(user);
    }

    //登录方法
    @Override
    public Integer selectUser(String userName, String password) {
        return userMapper.selectUser(userName, password);
    }

    //判断用户名是否重名
    @Override
    public Integer selectUserName(String userName) {
        return userMapper.selectUserName(userName);
    }

    //根据用户注册码查询用户信息
    @Override
    public UserInfo selectAll(String zhuce) {
        return userMapper.selectAll(zhuce);
    }

    //通过userid查询该id下的会员
    @Override
    public List<UserInfo> recursion(Long userId) {
        return userMapper.recursion(userId);
    }

    //通过姓名查询子会员
    @Override
    public UserInfo getAllNodes(String userName) {
        return userMapper.getAllNodes(userName);
    }

    //    @Override
//    public List<UserInfo> getAllByTime(UserInfo aa) {
//        return userMapper.getAllByTime(aa);
//    }
    @Override
    public IPage<UserInfo> listQueryUser(Page<UserInfo> page, String userName, Integer recommendationCode, String startTime, String endingTime) {
        QueryWrapper<UserInfo> queryWrapper = new QueryWrapper<UserInfo>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("user_name", userName);
        map.put("recommendation_code", recommendationCode);
        queryWrapper.allEq(map, false)
                .between(StringUtils.isNotEmpty(startTime) && StringUtils.isNotEmpty(endingTime),
                        "registration_time", startTime, endingTime);
        IPage<UserInfo> iPage = page(page, queryWrapper);

        return iPage;
    }

    @Override
    public IPage<UserInfo> selectAllByTime(Page<UserInfo> page , HashMap<String, Object> map) {
        return userMapper.getAllByTime(page,map);
    }



}
