package com.dodou.scaffold.controller;

import com.dodou.scaffold.dao.model.Stu;
import com.dodou.scaffold.service.FractionService;
import com.dodou.scaffold.service.StuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName StuAndFractionController
 * @Author Cjt
 * @Date 2019/9/1514:35
 * @Version 1.0
 */
@RestController
public class StuAndFractionController {
    @Autowired
    StuService stuService;
    @Autowired
    FractionService fractionService;
    @RequestMapping(value = "selectAll")
    public List<Stu> selectAll() {
        return stuService.selectAll();
    }
    @RequestMapping(value = "insertByList")
    public String insertByList() {
        List<Stu> aa = new ArrayList<Stu>();
        Stu m = new Stu();
        m.setStuName("小明");
        Stu h = new Stu();
        h.setStuName("小红");
        aa.add(m);
        aa.add(h);
        //stuService.insertByList(aa);
        if (stuService.saveBatch(aa, 2)) {
            return "添加成功!";
        } else {
            return "添加失败!";
        }
    }

}
